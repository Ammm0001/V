**Credit:**- github.com/wolfxd618

1. Install Termux from the Play Store. If you are on a PC, use Kali Linux or any other Linux distribution available in Windows.

2. Run the following commands one by one:
```
pkg update && pkg upgrade -y
```
```
pkg install php
```
```
pkg install git
```
3. Clone the repository:
```
https://github.com/ashtrobe/notpixel-adV2.git
```
4. Navigate to the repository:
```
cd notpixel-adV2
```
5. Run the main script:
```
php main.php
```
(if you run into any "CANNOT LINK EXECUTABLE" issue, run these commands) -
```
pkg install libicu -y
```
```
ln -s /data/data/com.termux/files/usr/lib/libicui.so.X /data/data/com.termux/files/usr/lib/libicui.so.76
```
```
pkg reinstall php
```
Then ```php main.php```

6. Choose the option to save accounts.

7. Paste your referral link and press Enter. If you have multiple accounts, Choose the option to save multiple accounts and save all your referral links.

8. Select option 2 to start earning.

It supports 100 accounts plus without proxy its safe to use with multiple accounts because its external script no use of Not pixel APIs.
